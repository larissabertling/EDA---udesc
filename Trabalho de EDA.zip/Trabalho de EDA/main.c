#include "script.h"
#include <stdio.h>
#include <stdlib.h>

//Karla Alexsandra de Souza Joriatti
//Larissa Regina Bertling

int main(void){
    int op = -1, n;
    float valor, alvo;
    celula *l;
    l = NULL;

    while (op != 0)
    {
        printf("\n__________________________________________\n\n");
        printf("|----------------Opções:-----------------|\n");
        printf("|1------Cadastrar uma série de dados-----|\n");
        printf("|2-----------Imprimir a série------------|\n");
        printf("|3----------Inserir novo valor-----------|\n");
        printf("|4-----------Remover um valor------------|\n");
        printf("|5---Trocar um valor da série por outro--|\n");
        printf("|----------------------------------------|\n");
        printf("|-------   Entre com 0 para sair   ------|\n");
        printf("__________________________________________\n");



        scanf("%d", &op);


        switch (op)
        {
        case 1:
            
            printf("Quantos valores deseja cadastrar? ");
            scanf("%d", &n);

            for(int i = 0; i < n; i++){
                printf("%dº: ", i+1);
                scanf("%f", &valor);

                l = insere_fim(l, valor);
            }

            break;

        case 2:

            imprime_serie(l);

            break;

        case 3:

            printf("Digite o valor a ser inserido: ");
            scanf("%f", &valor);

            l = insere_fim(l, valor);

            break;

        case 4:

            printf("Digite o valor a ser removido: ");
            scanf("%f", &valor);

            l = remove_valor(l, valor);

            break;

        case 5:

            printf("Valor a ser alterado: ");
            scanf("%f", &alvo);
            printf("Novo valor: ");
            scanf("%f", &valor);

            l = atualiza(l, alvo, valor);

            break;

        default:
            break;
        }
    }

    return 0;
}



void imprime_serie(celula *l){
	celula *p;
	p = l;

    if(l == NULL)
    {
        printf("\n\nERRO. NAO EXISTE SERIE CADASTRADA\n\n");
    }
    else
    {
        printf("\n\n_______________\n\n");

        while(p!= NULL){
            printf("|   %.4f   |\n", p->dado);
            p = p->prox;
        }

        printf("_______________\n\n");
    }

}
celula * insere_fim(celula *l, float valor){
    celula *novo, *p;
    p = l;
    novo = (celula *)malloc(sizeof(celula));
    novo -> dado = valor;
    novo -> prox = NULL;

    if(p != NULL)
    {
        while (p->prox != NULL)
            p = p->prox;
        p->prox = novo;
        novo->ant = p;
    }
    else
        l = novo;
    return l;
}

celula * remove_valor(celula *l, float valor){
    celula *p = l;

    while (p != NULL && p->dado != valor)
        p = p->prox;

    if (p == NULL)
    {
        printf("\n\nValor não encontrado\n\n");
        return l;
    }
    else
    {   
        if(p->ant == NULL)
            l = p->prox;
        else
        {
            if(p->prox != NULL)
                p->prox->ant = p->ant;

            p->ant->prox = p->prox;
        }

        free(p); 
    }

   return l; 
}

celula * atualiza(celula *l, float alvo, float valor){
    celula *p;
    p = l;

    while(p != NULL && p->dado != alvo)
        p = p->prox;
   
    if(p == NULL)
        printf("\n\nValor não encontrado\n\n");
    else
        p->dado = valor;

    return l;
}
