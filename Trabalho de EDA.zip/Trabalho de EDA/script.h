#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

typedef struct reg celula;
struct reg{
	float dado;
	celula * prox, *ant;
};

void imprime_serie(celula *l);
celula * insere_fim(celula *l, float valor);
celula * remove_valor(celula *l, float valor);
celula * atualiza(celula *l, float alvo, float valor);
