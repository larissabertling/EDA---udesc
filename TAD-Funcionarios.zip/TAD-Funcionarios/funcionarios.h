
struct reg{
	int cod;
	char nome[60];
	float salario;
};

typedef struct reg funcionario;

void mostraMenu();
void imprimeTodos(funcionario *v,int N);
void imprimePos(funcionario *v, int pos);
int maiorSalario(funcionario *v,int N);
int menorSalario(funcionario *v,int N);
float mediaSalarios(funcionario *v,int N);
funcionario * deletar(funcionario *v, int N);
funcionario * incluir(funcionario *v, int N);
