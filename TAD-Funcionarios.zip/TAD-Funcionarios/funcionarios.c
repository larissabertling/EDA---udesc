#include "funcionarios.h"
#include <stdio.h>
#include <stdlib.h>

void mostraMenu(){
	system("cls");//limpa a tela
	printf("|      CADASTRO DE FUNCION?RIOS      |\n");
	printf("|____________________________________|\n");
	printf("|           MENU DE OP��ES           |\n");
	printf("|------------------------------------|\n");
	printf("| 1 - INSERIR VALORES NO VETOR       |\n");
	printf("| 2 - IMPRIMIR TODOS OS FUNCION?RIOS |\n");
	printf("| 3 - IMPRIMIR FUNCION?RIO DA POSI??O|\n");	
	printf("| 4 - RETORNAR POS. DO MAIOR SAL?RIO |\n");
	printf("| 5 - RETORNAR POS. DO MENOR SAL?RIO |\n");
	printf("| 6 - RETORNAR A M?DIA DOS SAL?RIOS  |\n");
	printf("| 7 - REMOVER FUNCIONARIO            |\n");
	printf("| 8 - INCLUIR FUNCIONARIO            |\n");
	printf("| 0 - SAIR                           |\n");
	printf("|------------------------------------|\n");
}



/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: imprime todos os dados de funcionarios
@return: sem retorno
*/
void imprimeTodos(funcionario *v, int N){
	int i;
	for(i=0;i<N;i++){
		printf("Pos %i:\n",i);
		printf("C�digo: %d\n",v[i].cod);
		printf("Nome: %s\n",v[i].nome);
		printf("Sal�rio: %.2f\n",v[i].salario); //%.2f fara imprimir duas casas decimais depois da virgula
	}
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: imprime os dados do funcionario naquela posi��o
@return: sem retorno
*/
void imprimePos(funcionario *v, int pos){
	printf("Pos %i:\n",pos);
	printf("C�digo: %d\n",v[pos].cod);
	printf("Nome: %s\n",v[pos].nome);
	printf("Sal�rio: %.2f\n",v[pos].salario); 
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: busca o maior valor de salario no array
@return: retorna a posi��o do maior valor
*/
int maiorSalario(funcionario *v, int N){
	int i,maior;
	maior=0;
	for(i=0;i<N;i++){
		if(v[i].salario>v[maior].salario){
			maior=i;
		}
	}
	return(maior);
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: busca o menor valor de salario no array
@return: retorna a posi��o do menor valor
*/
int menorSalario(funcionario *v,int N){
	int i,menor;
	menor=0;
	for(i=0;i<N;i++){
		if(v[i].salario<v[menor].salario){
			menor=i;
		}
	}
	return(menor);
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: percorre o array acumulando a soma dos salarios, calcula a m�dia como a soma divida pelo n�mero de elementos
@return: retorna a m�dia
*/
float mediaSalarios(funcionario *v,int N){
	int i;
	float soma;
	soma=0.0;
	for(i=0;i<N;i++){
		soma+=v[i].salario;
	}
	return(soma/N);
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: insere o �ltimo valor do array na posicao a ser exclu�da e realoca o array com menos
uma posi��o
@return: retorna o array atualizado
*/
funcionario * deletar(funcionario *v, int N){
	int pos;
    printf("Qual a posi��o a excluir?");
    scanf("%d", &pos);
    if (pos >= 0 && pos < N){ //se a posi��o � valida
        v[pos]=v[N-1];
        v = (funcionario *)realloc(v, (N-1) * sizeof(funcionario)); 
    }
    return (v);
}

/*
@params: recebe um array v de funcionarios e o n�mero N de elementos no array
@oper: realoca o array com mais uma posi��o e insere o elemento lido do usu�rio nessa posi��o 
@return: retorna o array atualizado
*/
funcionario * incluir(funcionario *v, int N){
		v = (funcionario *) realloc(v, (N+1) * sizeof(funcionario)); 

    	printf("Pos %i:\n",N);
		printf("Digite o c�digo:\n");
		scanf("%d",&v[N].cod);
		printf("Digite o nome:\n");
		scanf("%s",&v[N].nome);
		printf("Digite o sal�rio:\n");
		scanf("%f",&v[N].salario);
		return(v);
		
}

