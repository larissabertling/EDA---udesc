#include "funcionarios.h"
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

main(){

setlocale(LC_ALL, "Portuguese");
	funcionario *vetor;
	int op,i,tmp,N=0,cod;
	do{
		mostraMenu();
		scanf("%d",&op);
		switch(op){
			case 1:
				if(N==0){
					printf("digite a quantidade de funcionarios que deseja cadastrar: ");
					scanf("%d",&N);
				
					vetor = (funcionario*)malloc(N*sizeof(funcionario));//vetor[N]

					for(i=0;i<N;i++){
						system("cls"); //isso vai limpar a tela
						vetor=incluir(vetor,i);
					}
				}
				else{
					printf("Seu vetor j� possui cadastros!\n");
					system("pause");
				}
				
				break;
			case 2:
				system("cls"); //limpa a tela
				imprimeTodos(vetor,N);
				system("pause"); //mensagem que espera o "enter"
				break;
			case 3:
				printf("Qual posi��oo quer imprimir?\n");
				scanf("%d",&tmp);
				imprimePos(vetor,tmp);
				system("pause");
				break;
			case 4:
				printf("O maior salario esta na posi��o %d\n",maiorSalario(vetor,N));  
				system("pause");
				break;
			case 5:
				printf("O menor salario esta na posi��o %d\n",menorSalario(vetor,N));  
				system("pause");
				break;
			case 6:
				printf("A m�dia dos sal�rios � %.2f\n",mediaSalarios(vetor,N));  
				system("pause");
				break;
			case 7:
				vetor=deletar(vetor,N);
				system("pause");
				N=N-1;
				break;
			case 8:
				vetor=incluir(vetor,N);
				system("pause");
				N=N+1;
				break;
			case 0:
				printf("Obrigado por usar o nosso programa!\n");  
				break;
			default:
				system("cls");
				printf("OP��O N�O CADASTRADA!\n");  
				system("pause");
				break;

		}
	}while(op!=0);
}


