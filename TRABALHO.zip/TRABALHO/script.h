#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct date tempo;
struct date{
	int dia, mes, ano, hora, minuto;
};

struct reg{
	int duracao, prioridade;
	char nome[30];
	tempo *deadline;
};

typedef struct task tarefa;
struct task{
	int id;
	struct reg *dados;
	tarefa *prox, *ant;//lista duplamente encadeada
};

tempo * verificar_data_atual();
int comparar_datas(tempo *data1, tempo *data2);
tarefa * organizar_deadline(tarefa *listaTarefas, tarefa *novaTarefa, int cont);
int busca_id(tarefa *listaTarefas, int num);
tarefa * cadastrar_tarefa(tarefa *listaTarefas, int cont);
tarefa * excluir_tarefa(tarefa *listaTarefas, int num);
tarefa * alterar_dados(tarefa *listaTarefas, int num, int cont);
int prioridade(tarefa *listaTarefas);
tarefa * indicar_tarefa_prioridade(tarefa *listaTarefas, int cont, tempo *data);
tarefa * indicar_tarefa(tarefa *listaTarefas, int cont, tempo *data);
