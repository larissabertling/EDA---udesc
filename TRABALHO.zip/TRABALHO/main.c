#include <stdio.h>
#include <string.h>
#include <time.h>
#include "script.c"

int main(void){
    tarefa *listaTarefas, *p, *a;
    tempo *data_atual;
    listaTarefas = (tarefa *)malloc(sizeof(tarefa));
    int op = -1, contador = 0, aux;

    while(op != 0){
        printf("\n\n|-----------------------------------------|\n");
        printf("|           CADASTRO DE TAREFAS           |\n");
        printf("|_________________________________________|\n");
        printf("|              MENU DE OPÇÕES             |\n");
        printf("|-----------------------------------------|\n");
        printf("| 1. INCLUIR NOVA TAREFA                  |\n");
        printf("| 2. VISUALIZAR TAREFAS CADASTRADAS       |\n");
        printf("| 3. EXCLUIR TAREFA                       |\n");
        printf("| 4. EDITAR TAREFA                        |\n");
        printf("| 5. INDICAR A TAREFA DO MOMENTO          |\n");
        printf("| 0. SAIR                                 |\n");
        printf("|-----------------------------------------|\n\n");

        printf("Opção: ");
        scanf("%i", &op);

        switch (op)
        {
        case 0:
            break;
        
        case 1:
            listaTarefas = cadastrar_tarefa(listaTarefas, contador);
            contador++;
            break;
        
        case 2:
            if(listaTarefas != NULL){
                p = listaTarefas;
                for(int n = 0; n < contador; n++){
                    printf("\n\n|  %s  |\n", p->dados->nome);
                    printf("ID: %i\n", p->id);
                    printf("DURAÇÃO: %i\n", p->dados->duracao);
                    printf("PRIORIDADE: %i\n", p->dados->prioridade);
                    printf("DEADLINE: %i/%i/%i  %i:%i\n\n", p->dados->deadline->dia, p->dados->deadline->mes, p->dados->deadline->ano, p->dados->deadline->hora, p->dados->deadline->minuto);

                    p = p->prox;
                }
            }
            else
                printf("\nNÃO EXISTEM TAREFAS CADASTRADAS! FAVOR UTILIZAR A OPÇÃO 1 PARA CADASTRAR UMA NOVA TAREFA\n");
            break;
        
        case 3:
            printf("\nEntre com o ID da tarefa que deseja excluir: ");
            scanf("%d", &aux);
            while (busca_id(listaTarefas, aux) == 0 && aux != -1)
            {
                printf("\nID NÃO CADASTRADO NO SISTEMA! ENTRE COM UM ID VÁLIDO OU COM -1 PARA CANCELAR A OPERAÇÃO.\nId: ");
                scanf("%d", &aux);
            }
            if(aux == -1)
                break;

            listaTarefas = excluir_tarefa(listaTarefas, aux);
            contador--;
            break;
            
        case 4:
            printf("\nEntre com o ID da tarefa que deseja alterar: ");
            scanf("%d", &aux);
            while(busca_id(listaTarefas, aux) == 0){
                printf("\nO ID INFORMADO NÃO EXISTE NO SISTEMA. ENTRE COM UM NOVO ID.\n");
                printf("ID da tarefa: ");
                scanf("%i", &aux);
            }

            listaTarefas = alterar_dados(listaTarefas, aux, contador);

            break;

        case 5:
            data_atual = verificar_data_atual();
            printf("\nData atual: %i/%i/%i %i:%i\n", data_atual->dia,data_atual->mes, data_atual->ano, data_atual->hora, data_atual->minuto);
            p = indicar_tarefa_prioridade(listaTarefas, contador, data_atual);
            a = indicar_tarefa(listaTarefas, contador, data_atual);

            if(a != NULL && p != NULL){
                printf("\n\n-------     TAREFAS INDICADAS PELO SISTEMA      ---------\n\n");
                printf("\nPor prioridade:\n");
                printf("|  %s  |\n", p->dados->nome);
                printf("ID: %i\n", p->id);
                printf("DURAÇÃO: %i\n", p->dados->duracao);
                printf("PRIORIDADE: %i\n", p->dados->prioridade);
                printf("DEADLINE: %i/%i/%i  %i:%i\n\n", p->dados->deadline->dia, p->dados->deadline->mes, p->dados->deadline->ano, p->dados->deadline->hora, p->dados->deadline->minuto);
                printf("\nPor limite de tempo:\n");
                printf("|  %s  |\n", a->dados->nome);
                printf("ID: %i\n", a->id);
                printf("DURAÇÃO: %i\n", a->dados->duracao);
                printf("PRIORIDADE: %i\n", a->dados->prioridade);
                printf("DEADLINE: %i/%i/%i  %i:%i\n\n", a->dados->deadline->dia, a->dados->deadline->mes, a->dados->deadline->ano, a->dados->deadline->hora, a->dados->deadline->minuto);
            }

            break;

        default:
            break;
        }

    }

    return 0;
}

