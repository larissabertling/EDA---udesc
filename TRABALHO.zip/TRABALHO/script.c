#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include "script.h"

tempo * verificar_data_atual(){
    //ponteiro para struct que armazena data e hora  
    struct tm *data_hora_atual;
    tempo *data;
	data = (tempo *)malloc(sizeof(tempo));
  
    //variável do tipo time_t para armazenar o tempo em segundos  
    time_t segundos;
  
    //obtendo o tempo em segundos  
    time(&segundos);   
  
    //para converter de segundos para o tempo local utilizamos a função localtime  
    data_hora_atual = localtime(&segundos);

	data->ano = data_hora_atual->tm_year+1900;
	data->dia = data_hora_atual->tm_mday;
	data->mes = data_hora_atual->tm_mon+1;
	data->hora = data_hora_atual->tm_hour;
	data->minuto = data_hora_atual->tm_min;

    return data;
}

//retorna 1 se a data1 é menor que a data2
//retorna 2 se a data2 é menor do que a data1
// e retorna -1 se elas forem iguais
int comparar_datas(tempo *data1, tempo *data2){
	if(data1->ano < data2->ano)
		return 1;
	else if(data1->ano > data2->ano)
		return 2;
	else{
		if (data1->mes < data2->mes)
			return 1;
		else if (data1->mes > data2->mes)
			return 2;
		else{
			if (data1->dia < data2->dia)
				return 1;
			else if (data1->dia > data2->dia)
				return 2;
			else{
				if (data1->hora < data2->hora)
					return 1;
				else if (data1->hora > data2->hora)
					return 2;
				else{
					if (data1->minuto < data2->minuto)
						return 1;
					else if (data1->minuto > data2->minuto)
						return 2;
					else
						return -1;
				}
			}
		}
	}
}

//incluir a novaTarefa na listaTarefas de acordo com a deadline.
tarefa * organizar_deadline(tarefa *listaTarefas, tarefa *novaTarefa,int cont){
	tarefa *l, *a, *cabeca;
	l = listaTarefas;
	cabeca = l;

	if (cont == 0)
		return novaTarefa;
	
	a = l->ant;

	while(l != NULL){
		if (comparar_datas(l->dados->deadline, novaTarefa->dados->deadline) == 2){
			novaTarefa->prox = l;
			novaTarefa->ant = a;
			l->ant = novaTarefa;
			if (a != NULL)
				a->prox = novaTarefa;
			else
				cabeca = novaTarefa;

			break;
		}
		else if(comparar_datas(l->dados->deadline, novaTarefa->dados->deadline) == -1){
			if (l->dados->prioridade > novaTarefa->dados->prioridade){
				novaTarefa->prox = l;
				novaTarefa->ant = a;
				l->ant = novaTarefa;
				if (a != NULL)
					a->prox = novaTarefa;
				else
					cabeca = novaTarefa;

				break;
			}
			else{
				a = l;
				l = l->prox;
			}
		}
		else{
			a = l;
			l = l->prox;
		}
	}

	if(l == NULL){
		a->prox = novaTarefa;
		novaTarefa->ant = a;
	}

	return cabeca;
}

//verificar se o id já existe na listaTarefas
int busca_id(tarefa *listaTarefas, int num){
    tarefa *l;
    l = listaTarefas;

    while(l != NULL){
        if(l->id == num)
            return 1;
        else
            l = l->prox;
    }

    return 0;
}

tarefa * cadastrar_tarefa(tarefa *listaTarefas, int cont){
	tarefa *newTask, *l;
	l = listaTarefas;
    newTask = (tarefa *)malloc(sizeof(tarefa));
    newTask->dados = (struct reg *)malloc(sizeof(struct reg));
    newTask->dados->deadline = (tempo *)malloc(sizeof(tempo));
	printf("Nome da tarefa: ");
	scanf(" %[^\n]", newTask->dados->nome);
	printf("ID da tarefa: ");
	scanf("%i", &newTask->id);
    while(busca_id(listaTarefas, newTask->id) == 1){
        printf("\nO ID INFORMADO JÁ EXISTE NO SISTEMA. ENTRE COM UM NOVO ID. CASO DESEJE ALTERAR OS ID'S POSTERIORMENTE, BASTA ENTRAR COM A OPÇÃO 4.\n");
        printf("ID da tarefa: ");
	    scanf("%i", &newTask->id);
    }
	printf("Nivel de Prioridade da tarefa: ");
	scanf("%i", &newTask->dados->prioridade);
	printf("Duração da tarefa(em minutos): ");
	scanf("%i", &newTask->dados->duracao);
	printf("\nDeadline\n");
	printf("Dia: ");
	scanf("%i", &newTask->dados->deadline->dia);
	printf("Mes: ");
	scanf("%i", &newTask->dados->deadline->mes);
    printf("Ano: ");
	scanf("%i", &newTask->dados->deadline->ano);
	printf("Hora: ");
	scanf("%i", &newTask->dados->deadline->hora);
	printf("Minuto: ");
	scanf("%i", &newTask->dados->deadline->minuto);

	newTask->ant = NULL;
	newTask->prox = NULL;

	l = organizar_deadline(listaTarefas, newTask, cont);
	return l;
}

tarefa * excluir_tarefa(tarefa *listaTarefas, int num){
    tarefa *l, *a, *p, *cabeca;
    l = listaTarefas;
    cabeca = l;

    while(l->id != num)
        l = l->prox;

    a = l->ant;
    p = l->prox;

    if(a == NULL){
        cabeca = p;
		if(p != NULL)
        	p->ant = NULL;
    }
    else if(p == NULL){
        a->prox = NULL;
    }
    else{
        a->prox = p;
        p->ant = a;
    }

    free(l);
    return cabeca;
}

tarefa * alterar_dados(tarefa *listaTarefas, int num, int cont){
	int aux, aux2;
	char op;
	tarefa *l, *cabeca, *newtask;
	newtask = (tarefa *)malloc(sizeof(tarefa));
    newtask->dados = (struct reg *)malloc(sizeof(struct reg));
    newtask->dados->deadline = (tempo *)malloc(sizeof(tempo));
	
	l = listaTarefas;
	cabeca = listaTarefas;


	while(l->id != num)
        l = l->prox;

	while(1){
		printf("\nQual informação deseja alterar?\n");
		printf("1.Nome da tarefa\n2.ID da tarefa\n3.Duração da tarefa\n4.Prioridade da tarefa\n5.Deadline da tarefa\n");
		scanf("%i", &aux);

		switch (aux)
		{
		case 1:
			printf("\nNovo nome para a tarefa: ");
			scanf(" %[^\n]", l->dados->nome);
			break;

		case 2:
			printf("\nNovo ID para a tarefa: ");
			scanf(" %i", &aux2);
			while(busca_id(listaTarefas, aux2) == 1){
				printf("\nO ID INFORMADO JÁ EXISTE NO SISTEMA. ENTRE COM UM NOVO ID.\n");
				printf("ID da tarefa: ");
				scanf("%i", &aux2);
    		}
			l->id = aux2;
			break;

		case 3:
			printf("\nNova duração da tarefa: ");
			scanf(" %i", &l->dados->duracao);
			break;

		case 4:
			printf("\nNova prioridade da tarefa: ");
			scanf(" %i", &l->dados->prioridade);
			break;

		case 5:
			printf("\nNova Deadline\n");
			printf("Dia: ");
			scanf("%i", &l->dados->deadline->dia);
			printf("Mes: ");
			scanf("%i", &l->dados->deadline->mes);
			printf("Ano: ");
			scanf("%i", &l->dados->deadline->ano);
			printf("Hora: ");
			scanf("%i", &l->dados->deadline->hora);
			printf("Minuto: ");
			scanf("%i", &l->dados->deadline->minuto);
			break;
		
		default:
			printf("\nOpção Inválida!\n");
			break;
		}
		getchar();
		printf("\nDeseja alterar algum outro dado? (y/n)\n");
		scanf("%c", &op);

		if(op == 'n'){
			strcpy(newtask->dados->nome, l->dados->nome);
			newtask->dados->deadline->ano = l->dados->deadline->ano;
			newtask->dados->deadline->mes = l->dados->deadline->mes;
			newtask->dados->deadline->dia = l->dados->deadline->dia;
			newtask->dados->deadline->hora = l->dados->deadline->hora;
			newtask->dados->deadline->minuto = l->dados->deadline->minuto;
			newtask->dados->duracao = l->dados->duracao;
			newtask->dados->prioridade = l->dados->prioridade;
			newtask->id = l->id;
			newtask->ant = NULL;
			newtask->prox = NULL;
			cabeca = excluir_tarefa(listaTarefas, l->id);
			cabeca = organizar_deadline(cabeca, newtask, cont-1);
			break;
		}

	}

	return cabeca;
}

//retorna a maior prioridade(menor valor)
int prioridade(tarefa *listaTarefas){
	tarefa *l;
	int menor_prioridade;
	l = listaTarefas;
	menor_prioridade = l->dados->prioridade;

	l = l->prox;

	while(l != NULL){
		if(l->dados->prioridade < menor_prioridade)
			menor_prioridade = l->dados->prioridade;
		
		l = l->prox;
	}

	return menor_prioridade;
}

tarefa * indicar_tarefa_prioridade(tarefa *listaTarefas, int cont, tempo *data){
	int prio = prioridade(listaTarefas), dia=0, mes=0, ano=0, hora=0, min=0, duracao,aux, tarefa_vencida = 0;
	tempo *menor_data, *data_auxiliar, *data_auxiliar2;
	data_auxiliar = (tempo *)malloc(sizeof(tempo));
	data_auxiliar2 = (tempo *)malloc(sizeof(tempo));
	menor_data = NULL;
	tarefa * l, *menor;
	l = listaTarefas;

	while(l != NULL){
		if(l->dados->prioridade == prio){
			dia=0, mes=0, ano=0, hora=0, min=0;
			duracao = l->dados->duracao;
			min = duracao%60;
			aux = duracao/60;
			if(aux != 0){
				hora = aux%24;
				aux = aux/24;
				if(aux != 0){
					dia = aux%30;
					aux = aux/30;
					if(aux != 0){
						mes = aux%12;
						ano = aux/12;
					}
				}
			}

			data_auxiliar->minuto = data->minuto + min;
			if(data_auxiliar->minuto >= 60){
				data_auxiliar->minuto-= 60;
				hora++;
			}
			data_auxiliar->hora = data->hora + hora;
			if(data_auxiliar->hora >= 24){
				data_auxiliar->hora-= 24;
				dia++;
			}
			data_auxiliar->dia = data->dia + dia;
			if(data_auxiliar->dia > 30){
				data_auxiliar->dia-= 30;
				mes++;
			}
			data_auxiliar->mes = data->mes + mes;
			if(data_auxiliar->mes >= 12){
				data_auxiliar->mes-=12;
				ano++;
			}
			data_auxiliar->ano = data->ano + ano;

			if(comparar_datas(data_auxiliar, l->dados->deadline) == 2){
				printf("\n\nTAREFA VENCIDA OU SEM TEMPO NECESSÁRIO PARA CONCLUSÃO!\n\n");
				printf("\n|  %s  |\n", l->dados->nome);
				printf("ID: %i\n", l->id);
				printf("DURAÇÃO: %i\n", l->dados->duracao);
				printf("PRIORIDADE: %i\n", l->dados->prioridade);
				printf("DEADLINE: %i/%i/%i  %i:%i\n\n", l->dados->deadline->dia, l->dados->deadline->mes, l->dados->deadline->ano, l->dados->deadline->hora, l->dados->deadline->minuto);
				tarefa_vencida = 1;
			}

			dia=0, mes=0, ano=0, hora=0, min=0;

			if(l->dados->deadline->minuto < data_auxiliar->minuto){
				data_auxiliar2->minuto = 60-data_auxiliar->minuto+l->dados->deadline->minuto;
				hora = -1;
			}else{
				data_auxiliar2->minuto = l->dados->deadline->minuto - data_auxiliar->minuto;
			}
			if(l->dados->deadline->hora < data_auxiliar->hora){
				data_auxiliar2->hora = 24-data_auxiliar->hora+l->dados->deadline->hora + hora;
				dia = -1;
			}else if(l->dados->deadline->hora == data_auxiliar->hora){
				if(hora != 0){
					data_auxiliar2->hora = 24 + hora;
				}else{
					data_auxiliar2->hora = 0;
				}
			}else{
				data_auxiliar2->hora = l->dados->deadline->hora - data_auxiliar->hora + hora;
			}
			if(l->dados->deadline->dia < data_auxiliar->dia){
				data_auxiliar2->dia = 30-data_auxiliar->dia+l->dados->deadline->dia + dia;
				mes = -1;
			}else{
				data_auxiliar2->dia = l->dados->deadline->dia - data_auxiliar->dia + dia;
			}
			if(l->dados->deadline->mes < data_auxiliar->mes){
				data_auxiliar2->mes = 12-data_auxiliar->mes+l->dados->deadline->mes + mes;
				ano = -1;
			}else{
				data_auxiliar2->mes = l->dados->deadline->mes - data_auxiliar->mes + mes;
			}
			data_auxiliar2->ano = l->dados->deadline->ano - data_auxiliar->ano + ano;

			if(menor_data == NULL){
				menor_data = (tempo *)malloc(sizeof(tempo));
				menor_data->ano = data_auxiliar2->ano;
				menor_data->mes = data_auxiliar2->mes;
				menor_data->dia = data_auxiliar2->dia;
				menor_data->hora = data_auxiliar2->hora;
				menor_data->minuto = data_auxiliar2->minuto;
				menor = l;
			}else if(comparar_datas(menor_data, data_auxiliar2) == 2){
				menor_data->ano = data_auxiliar2->ano;
				menor_data->mes = data_auxiliar2->mes;
				menor_data->dia = data_auxiliar2->dia;
				menor_data->hora = data_auxiliar2->hora;
				menor_data->minuto = data_auxiliar2->minuto;
				menor = l;
			}

		}
		l = l->prox;
	}

	if(tarefa_vencida)
		return NULL;
	else
		return menor;
}

tarefa * indicar_tarefa(tarefa *listaTarefas, int cont, tempo *data){
	int prio = prioridade(listaTarefas), dia=0, mes=0, ano=0, hora=0, min=0, duracao,aux, tarefa_vencida = 0;
	tempo *menor_data, *data_auxiliar, *data_auxiliar2;
	data_auxiliar = (tempo *)malloc(sizeof(tempo));
	data_auxiliar2 = (tempo *)malloc(sizeof(tempo));
	menor_data = NULL;
	tarefa * l, *menor;
	l = listaTarefas;

	while(l != NULL){
		if(l->dados->prioridade != prio){
			dia=0, mes=0, ano=0, hora=0, min=0;
			duracao = l->dados->duracao;
			min = duracao%60;
			aux = duracao/60;
			if(aux != 0){
				hora = aux%24;
				aux = aux/24;
				if(aux != 0){
					dia = aux%30;
					aux = aux/30;
					if(aux != 0){
						mes = aux%12;
						ano = aux/12;
					}
				}
			}

			data_auxiliar->minuto = data->minuto + min;
			if(data_auxiliar->minuto >= 60){
				data_auxiliar->minuto-= 60;
				hora++;
			}
			data_auxiliar->hora = data->hora + hora;
			if(data_auxiliar->hora >= 24){
				data_auxiliar->hora-= 24;
				dia++;
			}
			data_auxiliar->dia = data->dia + dia;
			if(data_auxiliar->dia >= 30){
				data_auxiliar->dia-= 30;
				mes++;
			}
			data_auxiliar->mes = data->mes + mes;
			if(data_auxiliar->mes >= 12){
				data_auxiliar->mes-=12;
				ano++;
			}
			data_auxiliar->ano = data->ano + ano;

			if(comparar_datas(data_auxiliar, l->dados->deadline) == 2){
				printf("\n\nTAREFA VENCIDA OU SEM TEMPO NECESSÁRIO PARA CONCLUSÃO!\n\n");
				printf("\n|  %s  |\n", l->dados->nome);
				printf("ID: %i\n", l->id);
				printf("DURAÇÃO: %i\n", l->dados->duracao);
				printf("PRIORIDADE: %i\n", l->dados->prioridade);
				printf("DEADLINE: %i/%i/%i  %i:%i\n\n", l->dados->deadline->dia, l->dados->deadline->mes, l->dados->deadline->ano, l->dados->deadline->hora, l->dados->deadline->minuto);
				tarefa_vencida = 1;
			}

			dia=0, mes=0, ano=0, hora=0, min=0;

			if(l->dados->deadline->minuto < data_auxiliar->minuto){
				data_auxiliar2->minuto = 60-data_auxiliar->minuto+l->dados->deadline->minuto;
				hora = -1;
			}else{
				data_auxiliar2->minuto = l->dados->deadline->minuto - data_auxiliar->minuto;
			}
			if(l->dados->deadline->hora < data_auxiliar->hora){
				data_auxiliar2->hora = 24-data_auxiliar->hora+l->dados->deadline->hora + hora;
				dia = -1;
			}else if(l->dados->deadline->hora == data_auxiliar->hora){
				if(hora != 0){
					data_auxiliar2->hora = 24 + hora;
				}else{
					data_auxiliar2->hora = 0;
				}
			}else{
				data_auxiliar2->hora = l->dados->deadline->hora - data_auxiliar->hora + hora;
			}
			if(l->dados->deadline->dia < data_auxiliar->dia){
				data_auxiliar2->dia = 30-data_auxiliar->dia+l->dados->deadline->dia + dia;
				mes = -1;
			}else{
				data_auxiliar2->dia = l->dados->deadline->dia - data_auxiliar->dia + dia;
			}
			if(l->dados->deadline->mes < data_auxiliar->mes){
				data_auxiliar2->mes = 12-data_auxiliar->mes+l->dados->deadline->mes + mes;
				ano = -1;
			}else{
				data_auxiliar2->mes = l->dados->deadline->mes - data_auxiliar->mes + mes;
			}
			data_auxiliar2->ano = l->dados->deadline->ano - data_auxiliar->ano + ano;

			if(menor_data == NULL){
				menor_data = (tempo *)malloc(sizeof(tempo));
				menor_data->ano = data_auxiliar2->ano;
				menor_data->mes = data_auxiliar2->mes;
				menor_data->dia = data_auxiliar2->dia;
				menor_data->hora = data_auxiliar2->hora;
				menor_data->minuto = data_auxiliar2->minuto;
				menor = l;
			}else if(comparar_datas(menor_data, data_auxiliar2) == 2){
				menor_data->ano = data_auxiliar2->ano;
				menor_data->mes = data_auxiliar2->mes;
				menor_data->dia = data_auxiliar2->dia;
				menor_data->hora = data_auxiliar2->hora;
				menor_data->minuto = data_auxiliar2->minuto;
				menor = l;
			}

		}
		l = l->prox;
	}

	if(tarefa_vencida)
		return NULL;
	else
		return menor;
}