typedef struct reg nodo;
typedef nodo *arvore;

struct reg{
	int chave;
	int conteudo;
	nodo *esq;
	nodo *dir;
};

nodo * cria_nodo (int chave, int conteudo);

arvore insere(arvore r, nodo * novo);

nodo * busca(arvore r, int k);

void erd (arvore r) ;

arvore remove_nodo(nodo *q);
arvore busca_remove(arvore a, int chave);
int altura(arvore a);
