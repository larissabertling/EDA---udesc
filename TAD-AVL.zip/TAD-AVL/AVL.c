#include <stdlib.h>
#include <stdio.h>
#include "AVL.h"

nodo * cria_nodo (int chave, int conteudo){
	nodo * novo = malloc (sizeof(nodo));
	novo->chave=chave;
	novo->conteudo=conteudo;
	novo->esq=NULL;
	novo->dir=NULL;
	return(novo);
}

nodo * rotDir(nodo * p){
	nodo *f = p->esq;
	p->esq=f->dir;
	f->dir=p;
	return(f);
}

nodo * rotEsq(nodo *p){
	nodo *f= p->dir; 
	p->dir=f->esq;
	f->esq=p;
	return(f);
}


int fator_balanceamento(arvore r){
	int bal;
	bal=altura(r->esq)-altura(r->dir);
	return(bal);
}

arvore balanceamento(arvore r){
	if(fator_balanceamento(r)>=2){
		if(fator_balanceamento(r->esq)<0) r->esq=rotEsq(r->esq); 
		r=rotDir(r);
	}
	else{
		if(fator_balanceamento(r)<=-2){
			if(fator_balanceamento(r->dir)>0) r->dir=rotDir(r->dir); 
			r=rotEsq(r);
		}
	}
	return r;
}

arvore insere(arvore r, nodo * novo){
	if(r==NULL) return novo;
	if(r->chave > novo->chave){
		r->esq = insere(r->esq,novo);
		r->esq = balanceamento(r->esq);
	}
	else{
		r->dir = insere(r->dir,novo);
		r->dir = balanceamento(r->dir);
	}	
	r=balanceamento(r);
	return r;
}

nodo * busca(arvore r, int k){
	if(r==NULL || r->chave == k)
		return r;
	if(r->chave > k)
		return busca(r->esq,k);
	else
		return busca(r->dir,k);
}

arvore remove_nodo(nodo *q){
	nodo *p, *f;
	if(q->dir ==NULL){//soh tem um dos filhos (esquerdo)
		f=q->esq;
		free(q);
		return(f);
	}
	p=f;
	f=q->dir;
	while(f->esq!=NULL){//procurando o sucessor
		p=f;
		f=f->esq;
	}
	//p est� apontando para o pai do sucesso
	//f est� apontando para o sucessor
	if(p!=q){
		p->esq=f->dir;//sucessor tem filho
		f->dir=q->dir;
	}//agora o filho assume o lugar do pai
	f->esq=q->esq;
	free(q);
	return(f);
}
	
arvore busca_remove_r(arvore a, int chave){
	if(a==NULL) return a;
	if(a->chave==chave) a=remove_nodo(a);
	else if(chave<a->chave) a->esq=busca_remove_r(a->esq,chave);
	else a->dir=busca_remove_r(a->dir,chave);
	a=balanceamento(a);
	return a;
}
	
	
arvore busca_remove(arvore a, int chave){
	nodo *p, *q;
	p=q=a;
	while(q->chave!=chave && q!=NULL){
		p=q;
		if(chave>q->chave) q=q->dir;
		else q=q->esq;
	}
	if(q==NULL)	return a; //nada a remover
	if(p==q) a=remove_nodo(q); //o alvo � a raiz
	else if(p->esq==q) p->esq=remove_nodo(q); //remover filho esquerdo
	else p->dir=remove_nodo(q); //remover filho direito
	return a;
}

int altura(arvore a){
	int esq,dir;
	if(a==NULL) return -1;
	esq=altura(a->esq);
	dir=altura(a->dir);
	if(esq>dir) return(1+esq);
	else return(1+dir);
}

void erd (arvore r) {
   if (r != NULL) {
      erd (r->esq);
      printf ("%d\n", r->conteudo);
      erd (r->dir); 
   }
}
