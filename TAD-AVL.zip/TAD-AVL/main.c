#include <stdio.h>
#include "AVL.h"

main(){
	nodo *a=NULL;
	a=insere(a,cria_nodo(8,8));
	printf("\nRaiz: %d\n",a->chave);
	a=insere(a,cria_nodo(7,7));
	printf("\nRaiz: %d\n",a->chave);
	a=insere(a,cria_nodo(5,5));
	printf("\nRaiz: %d\n",a->chave);
	a=insere(a,cria_nodo(3,3));
	printf("\nRaiz: %d\n",a->chave);
	//a=insere(a,cria_nodo(1,1));
	erd(a);
	printf("Altura: %d\n",altura(a));
	a=busca_remove_r(a,5);
	printf("Altura: %d\n",altura(a));
	erd(a);
	
	
}
