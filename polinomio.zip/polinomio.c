#include "polinomio.h"
#include <stdio.h>
#include <stdlib.h>


void mostrar(polinomio *x){
	int x, p, cont, coeficiente;
	polinomio *p;
	p = x;
	
	
	Printf("%d*x^%d", p->coeficiente, cont);
	
