struct reg{
	int coeficiente;
	polinomio *prox;
};

typedef struct reg polinomio;



